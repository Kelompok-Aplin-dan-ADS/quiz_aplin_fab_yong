		<script>
			$(document).ready(function() {
				M.AutoInit();
			});
		</script>
	</body>
</html>
        